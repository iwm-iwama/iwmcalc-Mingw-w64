static const uint16_t presym_length_table[] = {
  1,	/* ! */
  1,	/* % */
  1,	/* & */
  1,	/* * */
  1,	/* + */
  1,	/* - */
  1,	/* / */
  1,	/* < */
  1,	/* > */
  1,	/* E */
  1,	/* ^ */
  1,	/* ` */
  1,	/* a */
  1,	/* b */
  1,	/* c */
  1,	/* e */
  1,	/* h */
  1,	/* i */
  1,	/* k */
  1,	/* m */
  1,	/* n */
  1,	/* p */
  1,	/* r */
  1,	/* s */
  1,	/* v */
  1,	/* x */
  1,	/* y */
  1,	/* z */
  1,	/* | */
  1,	/* ~ */
  2,	/* != */
  2,	/* !~ */
  2,	/* $& */
  2,	/* $' */
  2,	/* $0 */
  2,	/* $` */
  2,	/* $~ */
  2,	/* && */
  2,	/* ** */
  2,	/* +@ */
  2,	/* -@ */
  2,	/* << */
  2,	/* <= */
  2,	/* == */
  2,	/* =~ */
  2,	/* >= */
  2,	/* >> */
  2,	/* GC */
  2,	/* PI */
  2,	/* [] */
  2,	/* ar */
  2,	/* bi */
  2,	/* bs */
  2,	/* cp */
  2,	/* ed */
  2,	/* ei */
  2,	/* lm */
  2,	/* ms */
  2,	/* pc */
  2,	/* re */
  2,	/* sv */
  2,	/* tr */
  2,	/* || */
  3,	/* <=> */
  3,	/* === */
  3,	/* NAN */
  3,	/* []= */
  3,	/* abs */
  3,	/* arg */
  3,	/* ary */
  3,	/* beg */
  3,	/* blk */
  3,	/* cap */
  3,	/* chr */
  3,	/* cmp */
  3,	/* cos */
  3,	/* div */
  3,	/* dup */
  3,	/* end */
  3,	/* env */
  3,	/* erf */
  3,	/* exp */
  3,	/* hex */
  3,	/* idx */
  3,	/* key */
  3,	/* len */
  3,	/* lim */
  3,	/* log */
  3,	/* map */
  3,	/* max */
  3,	/* min */
  3,	/* new */
  3,	/* num */
  3,	/* obj */
  3,	/* oct */
  3,	/* opt */
  3,	/* ord */
  3,	/* pat */
  3,	/* pop */
  3,	/* pos */
  3,	/* quo */
  3,	/* req */
  3,	/* ret */
  3,	/* sep */
  3,	/* sin */
  3,	/* str */
  3,	/* sub */
  3,	/* sym */
  3,	/* tan */
  3,	/* tr! */
  3,	/* val */
  4,	/* ARGV */
  4,	/* Hash */
  4,	/* Math */
  4,	/* NONE */
  4,	/* Proc */
  4,	/* abs2 */
  4,	/* acos */
  4,	/* all? */
  4,	/* any? */
  4,	/* arg1 */
  4,	/* arg2 */
  4,	/* args */
  4,	/* asin */
  4,	/* atan */
  4,	/* attr */
  4,	/* bind */
  4,	/* bsiz */
  4,	/* call */
  4,	/* cbrt */
  4,	/* ceil */
  4,	/* chop */
  4,	/* conj */
  4,	/* cosh */
  4,	/* dump */
  4,	/* each */
  4,	/* eql? */
  4,	/* erfc */
  4,	/* eval */
  4,	/* fdiv */
  4,	/* find */
  4,	/* flag */
  4,	/* grep */
  4,	/* gsub */
  4,	/* hash */
  4,	/* idx2 */
  4,	/* imag */
  4,	/* join */
  4,	/* key? */
  4,	/* keys */
  4,	/* last */
  4,	/* line */
  4,	/* log2 */
  4,	/* loop */
  4,	/* map! */
  4,	/* name */
  4,	/* nan? */
  4,	/* next */
  4,	/* nil? */
  4,	/* offs */
  4,	/* opts */
  4,	/* pad1 */
  4,	/* pad2 */
  4,	/* plen */
  4,	/* proc */
  4,	/* push */
  4,	/* puts */
  4,	/* real */
  4,	/* rect */
  4,	/* recv */
  4,	/* rest */
  4,	/* scan */
  4,	/* send */
  4,	/* sinh */
  4,	/* size */
  4,	/* sort */
  4,	/* sqrt */
  4,	/* step */
  4,	/* stop */
  4,	/* str2 */
  4,	/* sub! */
  4,	/* succ */
  4,	/* tanh */
  4,	/* to_a */
  4,	/* to_c */
  4,	/* to_f */
  4,	/* to_i */
  4,	/* to_r */
  4,	/* to_s */
  4,	/* tr_s */
  4,	/* type */
  4,	/* upto */
  4,	/* vals */
  5,	/* @args */
  5,	/* @data */
  5,	/* @name */
  5,	/* Array */
  5,	/* CMath */
  5,	/* Class */
  5,	/* Float */
  5,	/* Range */
  5,	/* _name */
  5,	/* _proc */
  5,	/* _recv */
  5,	/* acosh */
  5,	/* angle */
  5,	/* arity */
  5,	/* ary_F */
  5,	/* ary_T */
  5,	/* asinh */
  5,	/* assoc */
  5,	/* atan2 */
  5,	/* atanh */
  5,	/* begin */
  5,	/* block */
  5,	/* bytes */
  5,	/* capts */
  5,	/* chars */
  5,	/* chomp */
  5,	/* chop! */
  5,	/* class */
  5,	/* clear */
  5,	/* clone */
  5,	/* count */
  5,	/* curry */
  5,	/* first */
  5,	/* floor */
  5,	/* found */
  5,	/* frexp */
  5,	/* gsub! */
  5,	/* hypot */
  5,	/* index */
  5,	/* is_a? */
  5,	/* ldexp */
  5,	/* limit */
  5,	/* lines */
  5,	/* ljust */
  5,	/* log10 */
  5,	/* match */
  5,	/* merge */
  5,	/* names */
  5,	/* next! */
  5,	/* other */
  5,	/* owner */
  5,	/* phase */
  5,	/* polar */
  5,	/* pproc */
  5,	/* print */
  5,	/* quote */
  5,	/* raise */
  5,	/* real? */
  5,	/* rjust */
  5,	/* round */
  5,	/* shift */
  5,	/* slice */
  5,	/* sort! */
  5,	/* split */
  5,	/* start */
  5,	/* store */
  5,	/* strip */
  5,	/* succ! */
  5,	/* times */
  5,	/* total */
  5,	/* tr_s! */
  5,	/* width */
  5,	/* yield */
  5,	/* zero? */
  6,	/* $DEBUG */
  6,	/* @names */
  6,	/* Fixnum */
  6,	/* Kernel */
  6,	/* Method */
  6,	/* Module */
  6,	/* Object */
  6,	/* Regexp */
  6,	/* String */
  6,	/* Symbol */
  6,	/* __id__ */
  6,	/* _klass */
  6,	/* _owner */
  6,	/* center */
  6,	/* chomp! */
  6,	/* concat */
  6,	/* delete */
  6,	/* detect */
  6,	/* divmod */
  6,	/* downto */
  6,	/* empty? */
  6,	/* enable */
  6,	/* equal? */
  6,	/* escape */
  6,	/* extend */
  6,	/* finish */
  6,	/* freeze */
  6,	/* ifnone */
  6,	/* inject */
  6,	/* insert */
  6,	/* intern */
  6,	/* lambda */
  6,	/* length */
  6,	/* lstrip */
  6,	/* maxlen */
  6,	/* method */
  6,	/* offset */
  6,	/* others */
  6,	/* padstr */
  6,	/* printf */
  6,	/* public */
  6,	/* rassoc */
  6,	/* reduce */
  6,	/* regexp */
  6,	/* rehash */
  6,	/* reject */
  6,	/* result */
  6,	/* rindex */
  6,	/* rstrip */
  6,	/* select */
  6,	/* slice! */
  6,	/* source */
  6,	/* splice */
  6,	/* status */
  6,	/* string */
  6,	/* strip! */
  6,	/* to_int */
  6,	/* to_str */
  6,	/* to_sym */
  6,	/* unbind */
  6,	/* upcase */
  6,	/* value? */
  6,	/* values */
  7,	/* @regexp */
  7,	/* @source */
  7,	/* @string */
  7,	/* Binding */
  7,	/* Complex */
  7,	/* Integer */
  7,	/* Numeric */
  7,	/* __lines */
  7,	/* __merge */
  7,	/* binding */
  7,	/* casecmp */
  7,	/* collect */
  7,	/* compact */
  7,	/* compile */
  7,	/* current */
  7,	/* default */
  7,	/* delete! */
  7,	/* disable */
  7,	/* entries */
  7,	/* finite? */
  7,	/* frozen? */
  7,	/* getbyte */
  7,	/* include */
  7,	/* indexes */
  7,	/* inspect */
  7,	/* keyrest */
  7,	/* lambda? */
  7,	/* limited */
  7,	/* lstrip! */
  7,	/* member? */
  7,	/* message */
  7,	/* methods */
  7,	/* nesting */
  7,	/* numeric */
  7,	/* old_sub */
  7,	/* options */
  7,	/* padding */
  7,	/* pattern */
  7,	/* pointer */
  7,	/* prepend */
  7,	/* private */
  7,	/* reject! */
  7,	/* replace */
  7,	/* reverse */
  7,	/* rstrip! */
  7,	/* select! */
  7,	/* sep_len */
  7,	/* setbyte */
  7,	/* sprintf */
  7,	/* squeeze */
  7,	/* to_enum */
  7,	/* to_hash */
  7,	/* to_proc */
  7,	/* unshift */
  7,	/* upcase! */
  8,	/* @options */
  8,	/* EXTENDED */
  8,	/* INFINITY */
  8,	/* KeyError */
  8,	/* NilClass */
  8,	/* Rational */
  8,	/* __delete */
  8,	/* __send__ */
  8,	/* __svalue */
  8,	/* __to_int */
  8,	/* allocate */
  8,	/* between? */
  8,	/* bytesize */
  8,	/* captures */
  8,	/* casecmp? */
  8,	/* collect! */
  8,	/* default= */
  8,	/* downcase */
  8,	/* each_key */
  8,	/* extended */
  8,	/* find_all */
  8,	/* has_key? */
  8,	/* include? */
  8,	/* included */
  8,	/* kind_of? */
  8,	/* new_args */
  8,	/* old_gsub */
  8,	/* receiver */
  8,	/* reverse! */
  8,	/* self_len */
  8,	/* squeeze! */
  8,	/* str_each */
  8,	/* swapcase */
  8,	/* truncate */
  9,	/* Exception */
  9,	/* MULTILINE */
  9,	/* MatchData */
  9,	/* NameError */
  9,	/* TrueClass */
  9,	/* TypeError */
  9,	/* __compact */
  9,	/* __outer__ */
  9,	/* _gc_root_ */
  9,	/* _sys_fail */
  9,	/* ancestors */
  9,	/* backtrace */
  9,	/* bind_call */
  9,	/* byteindex */
  9,	/* byteslice */
  9,	/* casefold? */
  9,	/* conjugate */
  9,	/* const_get */
  9,	/* const_set */
  9,	/* constants */
  9,	/* delete_at */
  9,	/* downcase! */
  9,	/* each_byte */
  9,	/* each_char */
  9,	/* each_line */
  9,	/* end_with? */
  9,	/* exception */
  9,	/* exclusive */
  9,	/* imaginary */
  9,	/* infinite? */
  9,	/* inherited */
  9,	/* iterator? */
  9,	/* magnitude */
  9,	/* name_push */
  9,	/* negative? */
  9,	/* numerator */
  9,	/* object_id */
  9,	/* old_index */
  9,	/* old_slice */
  9,	/* old_split */
  9,	/* partition */
  9,	/* pre_match */
  9,	/* prepended */
  9,	/* protected */
  9,	/* separator */
  9,	/* swapcase! */
  9,	/* validated */
  9,	/* values_at */
  10,	/* Comparable */
  10,	/* Enumerable */
  10,	/* FalseClass */
  10,	/* IGNORECASE */
  10,	/* IndexError */
  10,	/* RangeError */
  10,	/* __case_eqq */
  10,	/* __num_to_a */
  10,	/* byterindex */
  10,	/* bytesplice */
  10,	/* capitalize */
  10,	/* class_eval */
  10,	/* codepoints */
  10,	/* each_index */
  10,	/* each_value */
  10,	/* given_args */
  10,	/* has_value? */
  10,	/* initialize */
  10,	/* last_match */
  10,	/* make_curry */
  10,	/* match_data */
  10,	/* old_slice! */
  10,	/* parameters */
  10,	/* post_match */
  10,	/* rpartition */
  10,	/* self_arity */
  10,	/* step_ratio */
  10,	/* superclass */
  10,	/* tail_empty */
  11,	/* @last_match */
  11,	/* BasicObject */
  11,	/* DomainError */
  11,	/* FrozenError */
  11,	/* RUBY_ENGINE */
  11,	/* RegexpError */
  11,	/* ScriptError */
  11,	/* SyntaxError */
  11,	/* ascii_only? */
  11,	/* attr_reader */
  11,	/* attr_writer */
  11,	/* capitalize! */
  11,	/* denominator */
  11,	/* last_match= */
  11,	/* module_eval */
  11,	/* rectangular */
  11,	/* respond_to? */
  11,	/* start_with? */
  11,	/* step_ratio= */
  12,	/* RUBY_VERSION */
  12,	/* RuntimeError */
  12,	/* __ENCODING__ */
  12,	/* __attached__ */
  12,	/* __codepoints */
  12,	/* alias_method */
  12,	/* block_given? */
  12,	/* default_proc */
  12,	/* escape_table */
  12,	/* exclude_end? */
  12,	/* instance_of? */
  12,	/* method_added */
  12,	/* remove_const */
  12,	/* super_method */
  12,	/* undef_method */
  13,	/* ArgumentError */
  13,	/* MRUBY_VERSION */
  13,	/* NoMemoryError */
  13,	/* NoMethodError */
  13,	/* StandardError */
  13,	/* StopIteration */
  13,	/* UnboundMethod */
  13,	/* __classname__ */
  13,	/* __sub_replace */
  13,	/* __update_hash */
  13,	/* attr_accessor */
  13,	/* const_missing */
  13,	/* default_proc= */
  13,	/* define_method */
  13,	/* delete_prefix */
  13,	/* delete_suffix */
  13,	/* extend_object */
  13,	/* instance_eval */
  13,	/* remove_method */
  13,	/* set_backtrace */
  14,	/* LocalJumpError */
  14,	/* __upto_endless */
  14,	/* const_defined? */
  14,	/* delete_prefix! */
  14,	/* delete_suffix! */
  14,	/* each_codepoint */
  14,	/* interval_ratio */
  14,	/* last_match_end */
  14,	/* method_missing */
  14,	/* method_removed */
  14,	/* named_captures */
  14,	/* paragraph_mode */
  14,	/* public_methods */
  15,	/* MRUBY_COPYRIGHT */
  15,	/* SystemCallError */
  15,	/* append_features */
  15,	/* class_variables */
  15,	/* each_with_index */
  15,	/* initialize_copy */
  15,	/* instance_method */
  15,	/* interval_ratio= */
  15,	/* local_variables */
  15,	/* method_defined? */
  15,	/* module_function */
  15,	/* pad_repetitions */
  15,	/* private_methods */
  15,	/* singleton_class */
  15,	/* source_location */
  15,	/* valid_encoding? */
  16,	/* FloatDomainError */
  16,	/* MRUBY_RELEASE_NO */
  16,	/* SystemStackError */
  16,	/* global_variables */
  16,	/* included_modules */
  16,	/* instance_methods */
  16,	/* prepend_features */
  16,	/* singleton_method */
  17,	/* MRUBY_DESCRIPTION */
  17,	/* ZeroDivisionError */
  17,	/* generational_mode */
  17,	/* protected_methods */
  17,	/* singleton_methods */
  18,	/* MRUBY_RELEASE_DATE */
  18,	/* class_variable_get */
  18,	/* class_variable_set */
  18,	/* generational_mode= */
  18,	/* instance_variables */
  18,	/* local_variable_get */
  18,	/* local_variable_set */
  19,	/* NotImplementedError */
  19,	/* RUBY_ENGINE_VERSION */
  19,	/* old_square_brancket */
  19,	/* respond_to_missing? */
  20,	/* __inspect_recursive? */
  21,	/* __coerce_step_counter */
  21,	/* instance_variable_get */
  21,	/* instance_variable_set */
  21,	/* remove_class_variable */
  22,	/* singleton_method_added */
  23,	/* _replace_back_reference */
  23,	/* class_variable_defined? */
  23,	/* define_singleton_method */
  23,	/* local_variable_defined? */
  24,	/* get_enable_option_string */
  24,	/* remove_instance_variable */
  25,	/* get_disable_option_string */
  26,	/* instance_variable_defined? */
  26,	/* undefined_instance_methods */
};

static const char * const presym_name_table[] = {
  "!",
  "%",
  "&",
  "*",
  "+",
  "-",
  "/",
  "<",
  ">",
  "E",
  "^",
  "`",
  "a",
  "b",
  "c",
  "e",
  "h",
  "i",
  "k",
  "m",
  "n",
  "p",
  "r",
  "s",
  "v",
  "x",
  "y",
  "z",
  "|",
  "~",
  "!=",
  "!~",
  "$&",
  "$'",
  "$0",
  "$`",
  "$~",
  "&&",
  "**",
  "+@",
  "-@",
  "<<",
  "<=",
  "==",
  "=~",
  ">=",
  ">>",
  "GC",
  "PI",
  "[]",
  "ar",
  "bi",
  "bs",
  "cp",
  "ed",
  "ei",
  "lm",
  "ms",
  "pc",
  "re",
  "sv",
  "tr",
  "||",
  "<=>",
  "===",
  "NAN",
  "[]=",
  "abs",
  "arg",
  "ary",
  "beg",
  "blk",
  "cap",
  "chr",
  "cmp",
  "cos",
  "div",
  "dup",
  "end",
  "env",
  "erf",
  "exp",
  "hex",
  "idx",
  "key",
  "len",
  "lim",
  "log",
  "map",
  "max",
  "min",
  "new",
  "num",
  "obj",
  "oct",
  "opt",
  "ord",
  "pat",
  "pop",
  "pos",
  "quo",
  "req",
  "ret",
  "sep",
  "sin",
  "str",
  "sub",
  "sym",
  "tan",
  "tr!",
  "val",
  "ARGV",
  "Hash",
  "Math",
  "NONE",
  "Proc",
  "abs2",
  "acos",
  "all?",
  "any?",
  "arg1",
  "arg2",
  "args",
  "asin",
  "atan",
  "attr",
  "bind",
  "bsiz",
  "call",
  "cbrt",
  "ceil",
  "chop",
  "conj",
  "cosh",
  "dump",
  "each",
  "eql?",
  "erfc",
  "eval",
  "fdiv",
  "find",
  "flag",
  "grep",
  "gsub",
  "hash",
  "idx2",
  "imag",
  "join",
  "key?",
  "keys",
  "last",
  "line",
  "log2",
  "loop",
  "map!",
  "name",
  "nan?",
  "next",
  "nil?",
  "offs",
  "opts",
  "pad1",
  "pad2",
  "plen",
  "proc",
  "push",
  "puts",
  "real",
  "rect",
  "recv",
  "rest",
  "scan",
  "send",
  "sinh",
  "size",
  "sort",
  "sqrt",
  "step",
  "stop",
  "str2",
  "sub!",
  "succ",
  "tanh",
  "to_a",
  "to_c",
  "to_f",
  "to_i",
  "to_r",
  "to_s",
  "tr_s",
  "type",
  "upto",
  "vals",
  "@args",
  "@data",
  "@name",
  "Array",
  "CMath",
  "Class",
  "Float",
  "Range",
  "_name",
  "_proc",
  "_recv",
  "acosh",
  "angle",
  "arity",
  "ary_F",
  "ary_T",
  "asinh",
  "assoc",
  "atan2",
  "atanh",
  "begin",
  "block",
  "bytes",
  "capts",
  "chars",
  "chomp",
  "chop!",
  "class",
  "clear",
  "clone",
  "count",
  "curry",
  "first",
  "floor",
  "found",
  "frexp",
  "gsub!",
  "hypot",
  "index",
  "is_a?",
  "ldexp",
  "limit",
  "lines",
  "ljust",
  "log10",
  "match",
  "merge",
  "names",
  "next!",
  "other",
  "owner",
  "phase",
  "polar",
  "pproc",
  "print",
  "quote",
  "raise",
  "real?",
  "rjust",
  "round",
  "shift",
  "slice",
  "sort!",
  "split",
  "start",
  "store",
  "strip",
  "succ!",
  "times",
  "total",
  "tr_s!",
  "width",
  "yield",
  "zero?",
  "$DEBUG",
  "@names",
  "Fixnum",
  "Kernel",
  "Method",
  "Module",
  "Object",
  "Regexp",
  "String",
  "Symbol",
  "__id__",
  "_klass",
  "_owner",
  "center",
  "chomp!",
  "concat",
  "delete",
  "detect",
  "divmod",
  "downto",
  "empty?",
  "enable",
  "equal?",
  "escape",
  "extend",
  "finish",
  "freeze",
  "ifnone",
  "inject",
  "insert",
  "intern",
  "lambda",
  "length",
  "lstrip",
  "maxlen",
  "method",
  "offset",
  "others",
  "padstr",
  "printf",
  "public",
  "rassoc",
  "reduce",
  "regexp",
  "rehash",
  "reject",
  "result",
  "rindex",
  "rstrip",
  "select",
  "slice!",
  "source",
  "splice",
  "status",
  "string",
  "strip!",
  "to_int",
  "to_str",
  "to_sym",
  "unbind",
  "upcase",
  "value?",
  "values",
  "@regexp",
  "@source",
  "@string",
  "Binding",
  "Complex",
  "Integer",
  "Numeric",
  "__lines",
  "__merge",
  "binding",
  "casecmp",
  "collect",
  "compact",
  "compile",
  "current",
  "default",
  "delete!",
  "disable",
  "entries",
  "finite?",
  "frozen?",
  "getbyte",
  "include",
  "indexes",
  "inspect",
  "keyrest",
  "lambda?",
  "limited",
  "lstrip!",
  "member?",
  "message",
  "methods",
  "nesting",
  "numeric",
  "old_sub",
  "options",
  "padding",
  "pattern",
  "pointer",
  "prepend",
  "private",
  "reject!",
  "replace",
  "reverse",
  "rstrip!",
  "select!",
  "sep_len",
  "setbyte",
  "sprintf",
  "squeeze",
  "to_enum",
  "to_hash",
  "to_proc",
  "unshift",
  "upcase!",
  "@options",
  "EXTENDED",
  "INFINITY",
  "KeyError",
  "NilClass",
  "Rational",
  "__delete",
  "__send__",
  "__svalue",
  "__to_int",
  "allocate",
  "between?",
  "bytesize",
  "captures",
  "casecmp?",
  "collect!",
  "default=",
  "downcase",
  "each_key",
  "extended",
  "find_all",
  "has_key?",
  "include?",
  "included",
  "kind_of?",
  "new_args",
  "old_gsub",
  "receiver",
  "reverse!",
  "self_len",
  "squeeze!",
  "str_each",
  "swapcase",
  "truncate",
  "Exception",
  "MULTILINE",
  "MatchData",
  "NameError",
  "TrueClass",
  "TypeError",
  "__compact",
  "__outer__",
  "_gc_root_",
  "_sys_fail",
  "ancestors",
  "backtrace",
  "bind_call",
  "byteindex",
  "byteslice",
  "casefold?",
  "conjugate",
  "const_get",
  "const_set",
  "constants",
  "delete_at",
  "downcase!",
  "each_byte",
  "each_char",
  "each_line",
  "end_with?",
  "exception",
  "exclusive",
  "imaginary",
  "infinite?",
  "inherited",
  "iterator?",
  "magnitude",
  "name_push",
  "negative?",
  "numerator",
  "object_id",
  "old_index",
  "old_slice",
  "old_split",
  "partition",
  "pre_match",
  "prepended",
  "protected",
  "separator",
  "swapcase!",
  "validated",
  "values_at",
  "Comparable",
  "Enumerable",
  "FalseClass",
  "IGNORECASE",
  "IndexError",
  "RangeError",
  "__case_eqq",
  "__num_to_a",
  "byterindex",
  "bytesplice",
  "capitalize",
  "class_eval",
  "codepoints",
  "each_index",
  "each_value",
  "given_args",
  "has_value?",
  "initialize",
  "last_match",
  "make_curry",
  "match_data",
  "old_slice!",
  "parameters",
  "post_match",
  "rpartition",
  "self_arity",
  "step_ratio",
  "superclass",
  "tail_empty",
  "@last_match",
  "BasicObject",
  "DomainError",
  "FrozenError",
  "RUBY_ENGINE",
  "RegexpError",
  "ScriptError",
  "SyntaxError",
  "ascii_only?",
  "attr_reader",
  "attr_writer",
  "capitalize!",
  "denominator",
  "last_match=",
  "module_eval",
  "rectangular",
  "respond_to?",
  "start_with?",
  "step_ratio=",
  "RUBY_VERSION",
  "RuntimeError",
  "__ENCODING__",
  "__attached__",
  "__codepoints",
  "alias_method",
  "block_given?",
  "default_proc",
  "escape_table",
  "exclude_end?",
  "instance_of?",
  "method_added",
  "remove_const",
  "super_method",
  "undef_method",
  "ArgumentError",
  "MRUBY_VERSION",
  "NoMemoryError",
  "NoMethodError",
  "StandardError",
  "StopIteration",
  "UnboundMethod",
  "__classname__",
  "__sub_replace",
  "__update_hash",
  "attr_accessor",
  "const_missing",
  "default_proc=",
  "define_method",
  "delete_prefix",
  "delete_suffix",
  "extend_object",
  "instance_eval",
  "remove_method",
  "set_backtrace",
  "LocalJumpError",
  "__upto_endless",
  "const_defined?",
  "delete_prefix!",
  "delete_suffix!",
  "each_codepoint",
  "interval_ratio",
  "last_match_end",
  "method_missing",
  "method_removed",
  "named_captures",
  "paragraph_mode",
  "public_methods",
  "MRUBY_COPYRIGHT",
  "SystemCallError",
  "append_features",
  "class_variables",
  "each_with_index",
  "initialize_copy",
  "instance_method",
  "interval_ratio=",
  "local_variables",
  "method_defined?",
  "module_function",
  "pad_repetitions",
  "private_methods",
  "singleton_class",
  "source_location",
  "valid_encoding?",
  "FloatDomainError",
  "MRUBY_RELEASE_NO",
  "SystemStackError",
  "global_variables",
  "included_modules",
  "instance_methods",
  "prepend_features",
  "singleton_method",
  "MRUBY_DESCRIPTION",
  "ZeroDivisionError",
  "generational_mode",
  "protected_methods",
  "singleton_methods",
  "MRUBY_RELEASE_DATE",
  "class_variable_get",
  "class_variable_set",
  "generational_mode=",
  "instance_variables",
  "local_variable_get",
  "local_variable_set",
  "NotImplementedError",
  "RUBY_ENGINE_VERSION",
  "old_square_brancket",
  "respond_to_missing?",
  "__inspect_recursive?",
  "__coerce_step_counter",
  "instance_variable_get",
  "instance_variable_set",
  "remove_class_variable",
  "singleton_method_added",
  "_replace_back_reference",
  "class_variable_defined?",
  "define_singleton_method",
  "local_variable_defined?",
  "get_enable_option_string",
  "remove_instance_variable",
  "get_disable_option_string",
  "instance_variable_defined?",
  "undefined_instance_methods",
};
